const presets = [
  [
    '@babel/env',
    {
      useBuiltIns: 'usage',
    },
    '@babel/typescript',
  ],
];

module.exports = { presets };
