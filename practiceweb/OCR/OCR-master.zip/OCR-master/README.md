# OCR
OCR in JavaScript with Tesseract.js
